using namespace std;

class Input{
	public :
		void cetak(){
			cout << "Aplikasi Pengelolaan Keuangan Bulanan" << endl;
			cout << "=====================================" << endl;
			cout << "Uang saku per Bulan : ";
			cin >> uangSaku;
			cout << "Pengeluaran berapa bulan : ";
			cin >> bulan;
			for (i = 0; i < bulan; i++){
        	cout << "Masukkan pengeluaran Bulan ke-" << i + 1 << " : "; 
			cin >> keluar[i];
      		}
		}
		void toFile(){
			tulis_data.open("api_data.txt");
			tulis_data << uangSaku << endl;
			tulis_data << bulan << endl;
			for(i = 0; i < bulan; i++){
        	tulis_data << keluar[i] << endl;
      		}
			tulis_data.close();
		}
		
	private :
		ofstream input_data;
		int uangSaku, bulan, i, keluar[20];
};